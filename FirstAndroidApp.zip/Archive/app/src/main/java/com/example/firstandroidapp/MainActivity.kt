package com.example.firstandroidapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.container)
    }
}

@Parcelize
data class Product (
    val name: String,
    val brand: String,
    val barcode: String,
    val nutriscore: Nutriscore,
    val urlImage: String,
    val quantity: String,
    val saleCountryList: List<String>,
    val ingrediantList: List<String>,
    val allergensList: List<String>,
    val additivesList: List<String>,
    //val nutritionFacts: NutritionFacts?
    ) : Parcelable

class NutritionFactsItem(
    val unit: String,
    val quantityPerPortion: Int,
    val quantityFor100g: Int
    )

class NutritionFacts(
    val energy: NutritionFactsItem,
    val lipid: NutritionFactsItem,
    val acid: NutritionFactsItem,
    val glucid: NutritionFactsItem,
    val sugar: NutritionFactsItem,
    val fiber: NutritionFactsItem,
    val protain: NutritionFactsItem,
    val salt: NutritionFactsItem,
    val sodium: NutritionFactsItem
)

enum class Nutriscore(val letter: String) {
    A("A"), B("B"), C("C"), D("D"), E("E")
}