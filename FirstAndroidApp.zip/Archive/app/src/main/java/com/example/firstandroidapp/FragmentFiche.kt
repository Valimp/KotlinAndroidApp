package com.example.firstandroidapp

import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide

class FicheFragment : Fragment() {


    // Equivalent du setContentView
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return LayoutInflater.from(requireContext()).inflate(
            R.layout.fragment_fiche,
            container, false,
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val currentProduct = Product(
            name = FicheFragmentArgs.fromBundle(requireArguments()).product.name,
            brand = FicheFragmentArgs.fromBundle(requireArguments()).product.brand,
            barcode = FicheFragmentArgs.fromBundle(requireArguments()).product.barcode,
            nutriscore = FicheFragmentArgs.fromBundle(requireArguments()).product.nutriscore,
            urlImage = FicheFragmentArgs.fromBundle(requireArguments()).product.urlImage,
            quantity = FicheFragmentArgs.fromBundle(requireArguments()).product.quantity,
            saleCountryList = FicheFragmentArgs.fromBundle(requireArguments()).product.saleCountryList,
            ingrediantList = FicheFragmentArgs.fromBundle(requireArguments()).product.ingrediantList,
            allergensList = FicheFragmentArgs.fromBundle(requireArguments()).product.allergensList,
            additivesList = FicheFragmentArgs.fromBundle(requireArguments()).product.additivesList
        )

        Glide.with(this).load(currentProduct.urlImage).into(view.findViewById(R.id.placeholderImage))

        view.findViewById<TextView>(R.id.name).setText(currentProduct.name)

        view.findViewById<TextView>(R.id.brand).setText(currentProduct.brand)

        view.findViewById<AppCompatImageView>(R.id.nutriscore).setImageResource(resources.getIdentifier(
            "nutriscore_${currentProduct.nutriscore.letter.lowercase()}",
            "drawable",
            requireContext().packageName,
        ))

        view.findViewById<TextView>(R.id.barcode).applyBoldText("Code-Barre", currentProduct.barcode)

        view.findViewById<TextView>(R.id.quantity).applyBoldText(
            "Quantité",
            if (currentProduct.quantity == "") {
                "Inconnue"
            } else {
                currentProduct.quantity
            }
        )

        view.findViewById<TextView>(R.id.saleCountry).applyBoldText(
            "Vendu en",
            if (currentProduct.saleCountryList.isEmpty()) {
                "Aucun pays revendeur"
            } else {
                currentProduct.saleCountryList.joinToString(", ")
            }
        )

        view.findViewById<TextView>(R.id.ingrediant).applyBoldText(
            "Ingrédiants",
            if (currentProduct.ingrediantList.isEmpty()) {
                "Inconnus"
            } else {
                currentProduct.ingrediantList.joinToString(", ")
            }
        )

        view.findViewById<TextView>(R.id.allergens).applyBoldText(
            "Allergènes",
            if (currentProduct.allergensList.isEmpty()) {
                "Aucun"
            } else {
                currentProduct.allergensList.joinToString(", ")
            }
        )

        view.findViewById<TextView>(R.id.additives).applyBoldText(
            "Additifs",
            if (currentProduct.additivesList.isEmpty()) {
                "Aucun"
            } else {
                currentProduct.additivesList.joinToString(", ")
            }
        )

    }

    private fun TextView.applyBoldText(prefix: String, value: String) {
        val text = "$prefix : $value"
        val builder = SpannableStringBuilder(text)
        builder.setSpan(StyleSpan(Typeface.BOLD), 0, text.indexOf(":") + 1, 0)
        setText(builder)
    }

}