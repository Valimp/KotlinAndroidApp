package com.example.firstandroidapp

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ListFragment : Fragment() {
    
    // Equivalent du setContentView
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return LayoutInflater.from(requireContext()).inflate(
            R.layout.fragment_list,
            container, false,
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val product1 = Product(
            name = "Petits pois et carottes",
            brand = "Cassegrin",
            barcode = "3083680085304",
            nutriscore = Nutriscore.E,
            urlImage = "https://static.openfoodfacts.org/images/products/308/368/008/5304/front_fr.7.400.jpg",
            quantity = "400g (280 g net égoutté)",
            saleCountryList = listOf("France", "Japon", "Suisse"),
            ingrediantList = listOf("Petits pois 66%", "eau", "garniture 2,8% (salade, oignon grelot)", "sucre", "sel", "arôme naturel"),
            allergensList = listOf(),
            additivesList = listOf(),
            //nutritionFacts = null
        )

        val product2 = Product(
            name = "Haricots verts et pommes de terre",
            brand = "Naturéco",
            barcode = "3760049791559",
            nutriscore = Nutriscore.B,
            urlImage = "https://images.openfoodfacts.org/images/products/301/780/000/4005/front_fr.27.full.jpg",
            quantity = "800g",
            saleCountryList = listOf("France"),
            ingrediantList = listOf("Haricots verts 47%", "pommes de terre 33%", "eau", "carottes", "oignons", "huile de tournesol", "sel"),
            allergensList = listOf(),
            additivesList = listOf(),
            //nutritionFacts = null
        )

        val product3 = Product(
            name = "Poêlée de légumes",
            brand = "Carrefour",
            barcode = "3270190023224",
            nutriscore = Nutriscore.A,
            urlImage = "https://images.openfoodfacts.org/images/products/308/368/111/7158/front_fr.16.full.jpg",
            quantity = "450g",
            saleCountryList = listOf("France"),
            ingrediantList = listOf("pommes de terre 27%", "carottes 27%", "haricots verts 16%", "oignons 10%", "petits pois 9%", "huile de colza", "sel", "poivre"),
            allergensList = listOf(),
            additivesList = listOf(),
            //nutritionFacts = null
        )

        val product4 = Product(
            name = "Ratatouille",
            brand = "Maison Castel",
            barcode = "3222476222565",
            nutriscore = Nutriscore.E,
            urlImage = "https://images.openfoodfacts.org/images/products/308/368/109/5296/front_fr.68.full.jpg",
            quantity = "375g",
            saleCountryList = listOf("France"),
            ingrediantList = listOf("tomates pelées concassées 31%", "courgettes 21%", "aubergines 15%", "poivrons rouges 14%", "oignons 10%", "huile d'olive", "sel", "ail", "origan"),
            allergensList = listOf(),
            additivesList = listOf(),
            //nutritionFacts = null
        )

        val product5 = Product(
            name = "Chili con carne",
            brand = "Côté Table",
            barcode = "3564709123551",
            nutriscore = Nutriscore.E,
            urlImage = "https://images.openfoodfacts.org/images/products/356/007/074/8938/front_fr.109.full.jpg",
            quantity = "800g",
            saleCountryList = listOf("France"),
            ingrediantList = listOf("viande de bœuf 27%", "haricots rouges 21%", "tomates pelées concassées 18%", "eau", "oignons 6%", "concentré de tomates 5%", "huile de colza", "sel", "paprika", "cumin", "ail"),
            allergensList = listOf(),
            additivesList = listOf(),
            //nutritionFacts = null
        )

        val cardsList = listOf<Product>(product1, product2, product3, product4, product5)

        view.findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = ListAdapter(cardsList, object : OnProductClickListener {
                override fun onProductClicked(product: Product) {
                    // Naviguate to the fiche page
                    findNavController().navigate(
                        ListFragmentDirections.actionListFragmentToFicheFragment(
                            product = product
                        )
                    )
                }
            })
        }
    }
}

class ListAdapter(
    private val listOfCards: List<Product>,
    val listener: OnProductClickListener,
) : RecyclerView.Adapter<PositionViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PositionViewHolder {
        return PositionViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.thumbnail, parent, false),
            listener
        )
    }

    override fun onBindViewHolder(holder: PositionViewHolder, position: Int) {
        holder.updateCell(listOfCards[position])
    }

    override fun getItemCount(): Int {
        return listOfCards.size
    }

}

class PositionViewHolder(v: View, val listener: OnProductClickListener) : RecyclerView.ViewHolder(v) {

    private val placeHolderCard : AppCompatImageView = v.findViewById(R.id.placeholderImageCard)
    private val nameCard : TextView = v.findViewById(R.id.nameCard)
    private val brandCard : TextView = v.findViewById(R.id.brandCard)
    private val nutriscoreCard : TextView = v.findViewById(R.id.nutriscoreCard)
    private val calorieCard : TextView = v.findViewById(R.id.caloriesCard)

    fun updateCell(product: Product) {
        itemView.setOnClickListener {
            listener.onProductClicked(product)
        }

        Glide.with(itemView.context).load(product.urlImage).into(placeHolderCard)
        nameCard.text = product.name
        brandCard.text = product.brand
        nutriscoreCard.text = "Nutriscore : " + product.nutriscore.letter
        calorieCard.text = "XXX kCal/portion"
    }

}

interface OnProductClickListener {
    fun onProductClicked(product: Product)
}